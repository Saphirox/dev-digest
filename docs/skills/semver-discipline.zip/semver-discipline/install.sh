#!/bin/sh
echo 'this script is never executed by the import'
