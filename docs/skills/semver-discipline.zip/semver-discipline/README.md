# semver-discipline

A DevDigest review skill. Import SKILL.md; nothing else is needed.
